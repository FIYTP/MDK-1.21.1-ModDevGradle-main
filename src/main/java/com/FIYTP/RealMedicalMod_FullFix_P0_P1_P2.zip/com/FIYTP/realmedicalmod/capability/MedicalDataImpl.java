package com.FIYTP.realmedicalmod.capability;

import com.FIYTP.realmedicalmod.config.MedicalConfig;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.common.util.INBTSerializable;

import java.util.EnumMap;
import java.util.Map;

public class MedicalDataImpl implements MedicalData, INBTSerializable<CompoundTag> {

    // ====== 全局生理数据 ======
    private int bloodVolume = 5000;
    private float bloodLossAccumulator = 0.0f;
    private float bloodRegenAccumulator = 0.0f;
    private float bloodOxygen = 98.0f;
    private float brainHealth = 100.0f;
    private int brainHealthRegenTimer = 0;
    private float consciousness = 100.0f;
    private int heartRate = 75;
    private int respirationRate = 16;
    private boolean underwater = false;
    private int underwaterTimer = 0;
    private boolean inVFib = false;
    private boolean cardiacArrest = false;

    // ====== 心脏计时器 ======
    private int vfibTimer = 0;
    private int bradyTimer = 0;
    private int hypoxiaTimer = 0;

    // ====== 疼痛衰减计时器 ======
    private int painDecayTimer = 0;

    // ====== 运动相关 ======
    private float exerciseIntensity = 0.0f;
    private float exerciseContribution = 0.0f;
    private int runningTimer = 0;
    private int attackTimer = 0;

    // ====== 心脏效果状态 ======
    private int heartEffectTimer = 0;
    private boolean heartEffectSevere = false;
    private boolean bradycardiaActive = false;
    private boolean bradycardiaSevere = false;

    // ====== 阿片类药物（支持浮点精细代谢与中枢镇痛） ======
    private float opioidConcentration = 0.0f;
    private int addictionLevel = 0;

    // ====== 肾上腺素系统（受创内源性应激 + 外源性自动注射器） ======
    private float adrenalineLevel = 0.0f;
    private int adrenalineCooldownSec = 0;
    private int adrenalineCrashSec = 0;
    private boolean adrenalineFromInjector = false;

    // ====== 纳洛酮拮抗与痛觉反跳状态 ======
    private int naloxoneEffectSec = 0;

    // ====== 非阿片类止痛药（布洛芬 NSAID —— 慢起效、低天花板镇痛） ======
    private int nsaidOnsetTimer = 0;
    private int nsaidRampTimer = 0;
    private int nsaidActiveTimer = 0;
    private int nsaidLimbReliefAccumSec = 0;
    private int nsaidLimbRelievedCount = 0;
    private int nsaidTargetLimbOrdinal = -1;

    // ====== 氨甲环酸内出血止血注射器 (TXA —— 抗纤溶促凝 + 过量高凝血栓风险) ======
    private float txaConcentration = 0.0f;

    // ====== 肢体数据 ======
    private final Map<Limb, LimbData> limbs = new EnumMap<>(Limb.class);

    // ====== 濒危状态 ======
    private boolean inCriticalState = false;
    private int criticalTimer = 0;

    // ====== 内出血与积血系统 ======
    private float chestBloodAccumulation = 0.0f;
    private int hemothoraxLevel = 0;
    private int hemothoraxVomitTimer = 0;
    private float lungContusion = 0.0f;
    private int fractureTraumaTimer = 0;
    private int intracranialBleedRate = 0;
    private float intracranialAccumulation = 0.0f;
    private int intracranialLevel = 0;
    private int intracranialOnsetTimer = 0;

    // ====== 血压与血流动力学 ======
    private int systolicBP = 120;
    private int diastolicBP = 80;
    private float meanArterialPressure = 93.0f;
    private float peripheralResistance = 1.0f;
    private float cardiacOutput = 5.25f;

    // ====== 感染与 SIRS 系统 ======
    private int sirsLevel = 0;
    private int sirsProgressionTimer = 0;
    private int sirsRecoveryTimer = 0;
    private boolean sirsActive = false;

    // ====== 中毒系统 ======
    private float toxinValue = 0.0f;

    // ====== 烧伤系统 (全身) ======
    private float burnTBSA = 0.0f;
    private float burnEdema = 0.0f;
    private float inhalationInjury = 0.0f;

    // ====== 脑损伤突发触发系统 ======
    private int brainDamageTriggerTimer = 0;
    private int brainDamageTriggerCooldown = 0;
    private boolean forcedTrigger90 = false;
    private boolean forcedTrigger60 = false;
    private boolean forcedTrigger30 = false;

    public MedicalDataImpl() {
        for (Limb limb : Limb.values()) {
            limbs.put(limb, new LimbDataImpl());
        }
    }

    // ====== Getter / Setter (全部 synchronized) ======
    @Override public synchronized int getBloodVolume() { return bloodVolume; }
    @Override public synchronized void setBloodVolume(int value) { this.bloodVolume = Math.max(0, value); }
    @Override public int getMaxBloodVolume() { return 5000; }

    @Override
    public synchronized float getBloodLossAccumulator() {
        return bloodLossAccumulator;
    }

    @Override
    public synchronized void setBloodLossAccumulator(float value) {
        this.bloodLossAccumulator = Math.max(0.0f, Math.min(1.0f, value));
    }

    @Override
    public synchronized float getBloodRegenAccumulator() {
        return bloodRegenAccumulator;
    }

    @Override
    public synchronized void setBloodRegenAccumulator(float value) {
        this.bloodRegenAccumulator = Math.max(0.0f, Math.min(1.0f, value));
    }

    @Override public synchronized int getBloodOxygen() { return Math.round(bloodOxygen); }
    @Override public synchronized void setBloodOxygen(int value) { this.bloodOxygen = Math.max(0.0f, Math.min(100.0f, (float) value)); }
    @Override public synchronized float getBloodOxygenFloat() { return bloodOxygen; }
    @Override public synchronized void setBloodOxygenFloat(float value) { this.bloodOxygen = Math.max(0.0f, Math.min(100.0f, value)); }

    @Override public synchronized int getBrainHealth() { return Math.round(brainHealth); }
    @Override public synchronized void setBrainHealth(int value) { this.brainHealth = Math.max(0.0f, Math.min(100.0f, (float) value)); }
    @Override public synchronized float getBrainHealthFloat() { return brainHealth; }
    @Override public synchronized void setBrainHealthFloat(float value) { this.brainHealth = Math.max(0.0f, Math.min(100.0f, value)); }
    @Override public synchronized int getBrainHealthRegenTimer() { return brainHealthRegenTimer; }
    @Override public synchronized void setBrainHealthRegenTimer(int seconds) { this.brainHealthRegenTimer = Math.max(0, seconds); }

    @Override public synchronized int getConsciousness() { return Math.round(consciousness); }
    @Override public synchronized void setConsciousness(int value) { this.consciousness = Math.max(0.0f, Math.min(100.0f, (float) value)); }
    @Override public synchronized float getConsciousnessFloat() { return consciousness; }
    @Override public synchronized void setConsciousnessFloat(float value) { this.consciousness = Math.max(0.0f, Math.min(100.0f, value)); }

    @Override public synchronized int getHeartRate() { return heartRate; }
    @Override public synchronized void setHeartRate(int value) { this.heartRate = Math.max(0, value); }

    @Override public synchronized int getRespirationRate() { return respirationRate; }
    @Override public synchronized void setRespirationRate(int value) { this.respirationRate = Math.max(0, value); }

    @Override public synchronized boolean isUnderwater() { return underwater; }
    @Override public synchronized void setUnderwater(boolean underwater) { this.underwater = underwater; }

    @Override public synchronized int getUnderwaterTimer() { return underwaterTimer; }
    @Override public synchronized void setUnderwaterTimer(int seconds) { this.underwaterTimer = Math.max(0, seconds); }

    @Override public synchronized boolean isInVFib() { return inVFib; }
    @Override public synchronized void setVFib(boolean vfib) { this.inVFib = vfib; }

    @Override public synchronized boolean isCardiacArrest() { return cardiacArrest; }
    @Override public synchronized void setCardiacArrest(boolean arrest) { this.cardiacArrest = arrest; }

    @Override public synchronized int getVfibTimer() { return vfibTimer; }
    @Override public synchronized void setVfibTimer(int seconds) { this.vfibTimer = Math.max(0, seconds); }

    @Override public synchronized int getBradyTimer() { return bradyTimer; }
    @Override public synchronized void setBradyTimer(int seconds) { this.bradyTimer = Math.max(0, seconds); }

    @Override public synchronized int getHypoxiaTimer() { return hypoxiaTimer; }
    @Override public synchronized void setHypoxiaTimer(int seconds) { this.hypoxiaTimer = Math.max(0, seconds); }

    @Override public synchronized int getPainDecayTimer() { return painDecayTimer; }
    @Override public synchronized void setPainDecayTimer(int seconds) { this.painDecayTimer = Math.max(0, seconds); }

    @Override public synchronized float getExerciseIntensity() { return exerciseIntensity; }
    @Override public synchronized void setExerciseIntensity(float intensity) {
        this.exerciseIntensity = Math.max(0.0f, Math.min(1.0f, intensity));
    }

    @Override public synchronized float getExerciseContribution() { return exerciseContribution; }
    @Override public synchronized void setExerciseContribution(float contribution) {
        this.exerciseContribution = Math.max(0.0f, contribution);
    }

    @Override public synchronized int getRunningTimer() { return runningTimer; }
    @Override public synchronized void setRunningTimer(int seconds) { this.runningTimer = Math.max(0, seconds); }

    @Override public synchronized int getAttackTimer() { return attackTimer; }
    @Override public synchronized void setAttackTimer(int seconds) { this.attackTimer = Math.max(0, seconds); }

    @Override public synchronized int getHeartEffectTimer() { return heartEffectTimer; }
    @Override public synchronized void setHeartEffectTimer(int seconds) { this.heartEffectTimer = Math.max(0, seconds); }

    @Override public synchronized boolean isHeartEffectSevere() { return heartEffectSevere; }
    @Override public synchronized void setHeartEffectSevere(boolean severe) { this.heartEffectSevere = severe; }

    @Override public synchronized boolean isBradycardiaActive() { return bradycardiaActive; }
    @Override public synchronized void setBradycardiaActive(boolean active) { this.bradycardiaActive = active; }

    @Override public synchronized boolean isBradycardiaSevere() { return bradycardiaSevere; }
    @Override public synchronized void setBradycardiaSevere(boolean severe) { this.bradycardiaSevere = severe; }

    @Override public synchronized int getOpioidConcentration() { return Math.round(opioidConcentration); }
    @Override public synchronized void setOpioidConcentration(int value) {
        this.opioidConcentration = Math.max(0.0f, Math.min(100.0f, (float) value));
    }
    public synchronized float getOpioidConcentrationFloat() { return opioidConcentration; }
    public synchronized void setOpioidConcentrationFloat(float value) {
        this.opioidConcentration = Math.max(0.0f, Math.min(100.0f, value));
    }
    @Override public synchronized boolean isInCriticalState() { return inCriticalState; }
    @Override public synchronized void setInCriticalState(boolean critical) { this.inCriticalState = critical; }
    @Override public synchronized int getCriticalTimer() { return criticalTimer; }
    @Override public synchronized void setCriticalTimer(int seconds) { this.criticalTimer = Math.max(0, seconds); }

    @Override public synchronized float getChestBloodAccumulation() { return chestBloodAccumulation; }
    @Override public synchronized void setChestBloodAccumulation(float value) { this.chestBloodAccumulation = Math.max(0.0f, Math.min(2000.0f, value)); }
    @Override public synchronized int getHemothoraxLevel() { return hemothoraxLevel; }
    @Override public synchronized void setHemothoraxLevel(int value) { this.hemothoraxLevel = Math.max(0, Math.min(4, value)); }
    @Override public synchronized int getHemothoraxVomitTimer() { return hemothoraxVomitTimer; }
    @Override public synchronized void setHemothoraxVomitTimer(int seconds) { this.hemothoraxVomitTimer = Math.max(0, seconds); }

    @Override public synchronized float getLungContusion() { return lungContusion; }
    @Override public synchronized void setLungContusion(float value) {
        this.lungContusion = Math.max(0.0f, Math.min(100.0f, value));
    }
    @Override public synchronized int getFractureTraumaTimer() { return fractureTraumaTimer; }
    @Override public synchronized void setFractureTraumaTimer(int seconds) {
        this.fractureTraumaTimer = Math.max(0, seconds);
    }

    @Override public synchronized int getIntracranialBleedRate() { return intracranialBleedRate; }
    @Override public synchronized void setIntracranialBleedRate(int value) { this.intracranialBleedRate = Math.max(0, Math.min(30, value)); }
    @Override public synchronized float getIntracranialAccumulation() { return intracranialAccumulation; }
    @Override public synchronized void setIntracranialAccumulation(float value) { this.intracranialAccumulation = Math.max(0.0f, Math.min(150.0f, value)); }
    @Override public synchronized int getIntracranialLevel() { return intracranialLevel; }
    @Override public synchronized void setIntracranialLevel(int value) { this.intracranialLevel = Math.max(0, Math.min(4, value)); }
    @Override public synchronized int getIntracranialOnsetTimer() { return intracranialOnsetTimer; }
    @Override public synchronized void setIntracranialOnsetTimer(int seconds) { this.intracranialOnsetTimer = Math.max(0, seconds); }

    // ====== 血压与血流动力学 Getter / Setter ======
    @Override public synchronized int getSystolicBP() { return systolicBP; }
    @Override public synchronized void setSystolicBP(int value) { this.systolicBP = value; }
    @Override public synchronized int getDiastolicBP() { return diastolicBP; }
    @Override public synchronized void setDiastolicBP(int value) { this.diastolicBP = value; }
    @Override public synchronized float getMeanArterialPressure() { return meanArterialPressure; }
    @Override public synchronized void setMeanArterialPressure(float value) { this.meanArterialPressure = value; }
    @Override public synchronized float getPeripheralResistance() { return peripheralResistance; }
    @Override public synchronized void setPeripheralResistance(float value) { this.peripheralResistance = value; }
    @Override public synchronized float getCardiacOutput() { return cardiacOutput; }
    @Override public synchronized void setCardiacOutput(float value) { this.cardiacOutput = value; }

    @Override public synchronized int getSirsLevel() { return sirsLevel; }
    @Override public synchronized void setSirsLevel(int level) { this.sirsLevel = Math.max(0, Math.min(4, level)); }
    @Override public synchronized int getSirsProgressionTimer() { return sirsProgressionTimer; }
    @Override public synchronized void setSirsProgressionTimer(int timer) { this.sirsProgressionTimer = Math.max(0, timer); }
    @Override public synchronized int getSirsRecoveryTimer() { return sirsRecoveryTimer; }
    @Override public synchronized void setSirsRecoveryTimer(int timer) { this.sirsRecoveryTimer = Math.max(0, timer); }
    @Override public synchronized boolean isSirsActive() { return sirsActive; }
    @Override public synchronized void setSirsActive(boolean active) { this.sirsActive = active; }

    // ====== 中毒系统 ======
    @Override public synchronized float getToxinValue() { return toxinValue; }
    @Override public synchronized void setToxinValue(float value) { this.toxinValue = Math.max(0.0f, Math.min(100.0f, value)); }
    @Override public synchronized void addToxinValue(float amount) { this.toxinValue = Math.max(0.0f, Math.min(100.0f, this.toxinValue + amount)); }

    // ====== 烧伤系统（全身） ======
    @Override public synchronized float getBurnTBSA() { return burnTBSA; }
    @Override public synchronized void setBurnTBSA(float tbsa) { this.burnTBSA = Math.max(0.0f, Math.min(100.0f, tbsa)); }
    @Override public synchronized float getBurnEdema() { return burnEdema; }
    @Override public synchronized void setBurnEdema(float edema) { this.burnEdema = Math.max(0.0f, Math.min(5000.0f, edema)); }
    @Override public synchronized float getInhalationInjury() { return inhalationInjury; }
    @Override public synchronized void setInhalationInjury(float severity) { this.inhalationInjury = Math.max(0.0f, Math.min(1.0f, severity)); }

    @Override public synchronized int getBrainDamageTriggerTimer() { return brainDamageTriggerTimer; }
    @Override public synchronized void setBrainDamageTriggerTimer(int seconds) { this.brainDamageTriggerTimer = Math.max(0, seconds); }
    @Override public synchronized int getBrainDamageTriggerCooldown() { return brainDamageTriggerCooldown; }
    @Override public synchronized void setBrainDamageTriggerCooldown(int seconds) { this.brainDamageTriggerCooldown = Math.max(0, seconds); }
    @Override public synchronized boolean hasForcedTrigger90() { return forcedTrigger90; }
    @Override public synchronized void setForcedTrigger90(boolean value) { this.forcedTrigger90 = value; }
    @Override public synchronized boolean hasForcedTrigger60() { return forcedTrigger60; }
    @Override public synchronized void setForcedTrigger60(boolean value) { this.forcedTrigger60 = value; }
    @Override public synchronized boolean hasForcedTrigger30() { return forcedTrigger30; }
    @Override public synchronized void setForcedTrigger30(boolean value) { this.forcedTrigger30 = value; }

    @Override public synchronized int getAddictionLevel() { return addictionLevel; }
    @Override public synchronized void setAddictionLevel(int value) {
        this.addictionLevel = Math.max(0, Math.min(100, value));
    }

    // ====== 肾上腺素 Getter / Setter ======
    public synchronized int getAdrenalineLevel() { return Math.round(adrenalineLevel); }
    public synchronized float getAdrenalineLevelFloat() { return adrenalineLevel; }
    public synchronized void setAdrenalineLevelFloat(float value) {
        this.adrenalineLevel = Math.max(0.0f, Math.min(100.0f, value));
    }
    public synchronized int getAdrenalineCooldownSec() { return adrenalineCooldownSec; }
    public synchronized void setAdrenalineCooldownSec(int sec) { this.adrenalineCooldownSec = Math.max(0, sec); }
    public synchronized int getAdrenalineCrashSec() { return adrenalineCrashSec; }
    public synchronized void setAdrenalineCrashSec(int sec) { this.adrenalineCrashSec = Math.max(0, sec); }
    public synchronized boolean isAdrenalineFromInjector() { return adrenalineFromInjector; }
    public synchronized void setAdrenalineFromInjector(boolean fromInjector) { this.adrenalineFromInjector = fromInjector; }

    public synchronized int getNaloxoneEffectSec() { return naloxoneEffectSec; }
    public synchronized void setNaloxoneEffectSec(int sec) { this.naloxoneEffectSec = Math.max(0, sec); }

    public synchronized int getNsaidOnsetTimer() { return nsaidOnsetTimer; }
    public synchronized void setNsaidOnsetTimer(int sec) { this.nsaidOnsetTimer = Math.max(0, sec); }

    public synchronized int getNsaidRampTimer() { return nsaidRampTimer; }
    public synchronized void setNsaidRampTimer(int sec) { this.nsaidRampTimer = Math.max(0, sec); }

    public synchronized int getNsaidActiveTimer() { return nsaidActiveTimer; }
    public synchronized void setNsaidActiveTimer(int sec) { this.nsaidActiveTimer = Math.max(0, sec); }

    public synchronized int getNsaidLimbReliefAccumSec() { return nsaidLimbReliefAccumSec; }
    public synchronized void setNsaidLimbReliefAccumSec(int sec) { this.nsaidLimbReliefAccumSec = Math.max(0, sec); }

    public synchronized int getNsaidLimbRelievedCount() { return nsaidLimbRelievedCount; }
    public synchronized void setNsaidLimbRelievedCount(int count) { this.nsaidLimbRelievedCount = Math.max(0, count); }

    public synchronized int getNsaidTargetLimbOrdinal() { return nsaidTargetLimbOrdinal; }
    public synchronized void setNsaidTargetLimbOrdinal(int ord) { this.nsaidTargetLimbOrdinal = ord; }

    public synchronized float getTxaConcentration() { return txaConcentration; }
    public synchronized void setTxaConcentration(float val) { this.txaConcentration = Math.max(0.0f, Math.min(100.0f, val)); }

    @Override
    public synchronized int getTotalPainLevel() {
        int total = 0;
        for (LimbData ld : limbs.values()) {
            total += ld.getPainLevel();
        }
        return total;
    }

    // ★★★★★ 体感疼痛 (0 ~ MAX_PERCEIVED_PAIN，由 MedicalConfig 驱动的非线性主痛源模型) ★★★★★
    @Override
    public synchronized int getPerceivedPain() {
        double maxLimbPain = Math.max(1, MedicalConfig.MAX_PAIN_LEVEL.get());
        int maxPerceivedCap = Math.max(10, MedicalConfig.MAX_PERCEIVED_PAIN.get());
        double exponent = MedicalConfig.PAIN_LIMB_EXPONENT.get();
        double dominantWeight = MedicalConfig.PAIN_DOMINANT_LIMB_WEIGHT.get();
        double secondaryWeight = MedicalConfig.PAIN_SECONDARY_LIMB_WEIGHT.get();

        double maxScore = 0.0;
        double sumOtherScores = 0.0;
        for (LimbData ld : limbs.values()) {
            int pain = ld.getPainLevel();
            if (pain <= 0) continue;
            double norm = Math.min(1.0, Math.max(0.0, pain / maxLimbPain));
            double score = Math.pow(norm, exponent);
            if (score > maxScore) {
                sumOtherScores += maxScore;
                maxScore = score;
            } else {
                sumOtherScores += score;
            }
        }
        double rawResult = maxScore * dominantWeight + sumOtherScores * secondaryWeight;

        // ★ 中枢 μ-阿片受体强效镇痛抑制（若处于纳洛酮受体阻断期，镇痛被竞争性剥夺并引发痛觉过敏反跳） ★
        if (this.opioidConcentration > 0.01f) {
            double fullConc = Math.max(1.0, MedicalConfig.OPIOID_ANALGESIA_FULL_CONCENTRATION.get());
            double maxRelief = MedicalConfig.OPIOID_CENTRAL_ANALGESIA_MAX_REDUCTION.get();
            double analgesiaExp = Math.max(0.2, MedicalConfig.OPIOID_ANALGESIA_CURVE_EXPONENT.get());
            double blockMax = MedicalConfig.OPIOID_PAIN_TRANSMISSION_BLOCK.get();
            double antagonistFactor = (this.naloxoneEffectSec > 0)
                    ? MedicalConfig.NALOXONE_RECEPTOR_BLOCK_FACTOR.get()
                    : 1.0;

            double ratio = Math.min(1.0, this.opioidConcentration / fullConc);
            double curve = Math.pow(ratio, analgesiaExp) * antagonistFactor;
            double blockFactor = Math.max(0.0, 1.0 - curve * blockMax);
            rawResult = Math.max(0.0, rawResult * blockFactor - maxRelief * curve * 0.45);
        }
        // ★ 非阿片类止痛药（布洛芬）：仅在度过胃肠潜伏期后缓慢爬坡生效，且具有严格的天花板上限 ★
        if (this.nsaidActiveTimer > 0 && this.nsaidOnsetTimer <= 0 && rawResult > 0.0) {
            double rampFullSec = Math.max(1.0, MedicalConfig.NSAID_RAMP_UP_SEC.get());
            double rampFactor = Math.min(1.0, this.nsaidRampTimer / rampFullSec);
            double maxNsaidRelief = MedicalConfig.NSAID_MAX_PERCEIVED_PAIN_REDUCTION.get();
            rawResult = Math.max(0.0, rawResult - maxNsaidRelief * rampFactor);
        }

        if (this.naloxoneEffectSec > 0 && rawResult > 0.0) {
            rawResult *= MedicalConfig.NALOXONE_HYPERALGESIA_MULTIPLIER.get();
        }

        int result = (int) Math.round(rawResult);
        return Math.min(maxPerceivedCap, Math.max(0, result));
    }

    @Override public synchronized LimbData getLimb(Limb limb) { return limbs.get(limb); }
    @Override public synchronized Map<Limb, LimbData> getAllLimbs() { return limbs; }

    @Override
    public synchronized void copyFrom(MedicalData other) {
        this.bloodVolume = other.getBloodVolume();
        this.bloodLossAccumulator = other.getBloodLossAccumulator();
        this.bloodRegenAccumulator = other.getBloodRegenAccumulator();
        this.bloodOxygen = other.getBloodOxygenFloat();
        this.brainHealth = other.getBrainHealthFloat();
        this.brainHealthRegenTimer = other.getBrainHealthRegenTimer();
        this.consciousness = other.getConsciousnessFloat();
        this.heartRate = other.getHeartRate();
        this.respirationRate = other.getRespirationRate();
        this.underwater = other.isUnderwater();
        this.underwaterTimer = other.getUnderwaterTimer();
        this.inVFib = other.isInVFib();
        this.cardiacArrest = other.isCardiacArrest();
        this.inCriticalState = other.isInCriticalState();
        this.criticalTimer = other.getCriticalTimer();
        this.chestBloodAccumulation = other.getChestBloodAccumulation();
        this.hemothoraxLevel = other.getHemothoraxLevel();
        this.hemothoraxVomitTimer = other.getHemothoraxVomitTimer();
        this.lungContusion = other.getLungContusion();
        this.fractureTraumaTimer = other.getFractureTraumaTimer();
        this.intracranialBleedRate = other.getIntracranialBleedRate();
        this.intracranialAccumulation = other.getIntracranialAccumulation();
        this.intracranialLevel = other.getIntracranialLevel();
        this.intracranialOnsetTimer = other.getIntracranialOnsetTimer();
        this.systolicBP = other.getSystolicBP();
        this.diastolicBP = other.getDiastolicBP();
        this.meanArterialPressure = other.getMeanArterialPressure();
        this.peripheralResistance = other.getPeripheralResistance();
        this.cardiacOutput = other.getCardiacOutput();
        this.sirsLevel = other.getSirsLevel();
        this.sirsProgressionTimer = other.getSirsProgressionTimer();
        this.sirsRecoveryTimer = other.getSirsRecoveryTimer();
        this.sirsActive = other.isSirsActive();
        this.toxinValue = other.getToxinValue();
        this.brainDamageTriggerTimer = other.getBrainDamageTriggerTimer();
        this.brainDamageTriggerCooldown = other.getBrainDamageTriggerCooldown();
        this.forcedTrigger90 = other.hasForcedTrigger90();
        this.forcedTrigger60 = other.hasForcedTrigger60();
        this.forcedTrigger30 = other.hasForcedTrigger30();
        this.vfibTimer = other.getVfibTimer();
        this.bradyTimer = other.getBradyTimer();
        this.hypoxiaTimer = other.getHypoxiaTimer();
        this.painDecayTimer = other.getPainDecayTimer();
        this.exerciseIntensity = other.getExerciseIntensity();
        this.exerciseContribution = other.getExerciseContribution();
        this.runningTimer = other.getRunningTimer();
        this.attackTimer = other.getAttackTimer();
        this.heartEffectTimer = other.getHeartEffectTimer();
        this.heartEffectSevere = other.isHeartEffectSevere();
        this.bradycardiaActive = other.isBradycardiaActive();
        this.bradycardiaSevere = other.isBradycardiaSevere();
        this.opioidConcentration = (other instanceof MedicalDataImpl oImpl)
                ? oImpl.getOpioidConcentrationFloat()
                : (float) other.getOpioidConcentration();
        this.addictionLevel = other.getAddictionLevel();
        if (other instanceof MedicalDataImpl oAdr) {
            this.adrenalineLevel = oAdr.getAdrenalineLevelFloat();
            this.adrenalineCooldownSec = oAdr.getAdrenalineCooldownSec();
            this.adrenalineCrashSec = oAdr.getAdrenalineCrashSec();
            this.adrenalineFromInjector = oAdr.isAdrenalineFromInjector();
            this.naloxoneEffectSec = oAdr.getNaloxoneEffectSec();
            this.nsaidOnsetTimer = oAdr.getNsaidOnsetTimer();
            this.nsaidRampTimer = oAdr.getNsaidRampTimer();
            this.nsaidActiveTimer = oAdr.getNsaidActiveTimer();
            this.nsaidLimbReliefAccumSec = oAdr.getNsaidLimbReliefAccumSec();
            this.nsaidLimbRelievedCount = oAdr.getNsaidLimbRelievedCount();
            this.nsaidTargetLimbOrdinal = oAdr.getNsaidTargetLimbOrdinal();
            this.txaConcentration = oAdr.getTxaConcentration();
        }
        this.burnTBSA = other.getBurnTBSA();
        this.burnEdema = other.getBurnEdema();
        this.inhalationInjury = other.getInhalationInjury();
        for (Limb limb : Limb.values()) {
            LimbData src = other.getLimb(limb);
            LimbData dst = limbs.get(limb);
            dst.setBleeding(src.getBleeding());
            dst.setPainLevel(src.getPainLevel());
            dst.setBandaged(src.isBandaged());
            dst.setTourniqueted(src.isTourniqueted());
            dst.setInfection(src.getInfection());
            dst.setInfectionAgeTimer(src.getInfectionAgeTimer());
            dst.setOpenWound(src.hasOpenWound());
            dst.setInternalBleedingRate(src.getInternalBleedingRate());
            dst.setFracture(src.hasFracture());
            dst.setFractureTimer(src.getFractureTimer());
            dst.setOpenFracture(src.isOpenFracture());
            dst.setSplint(src.hasSplint());
            dst.setDislocation(src.hasDislocation());
            dst.setPerforation(src.hasPerforation());
            dst.setNaturalClottingTimer(src.getNaturalClottingTimer());
            dst.setClottingStartRate(src.getClottingStartRate());
            dst.setInternalHealingTimer(src.getInternalHealingTimer());
            dst.setDisinfectantTimer(src.getDisinfectantTimer());
            dst.setInfectionAccumulator(src.getInfectionAccumulator());
            dst.setBurnLoad(src.getBurnLoad());
            dst.setBurnConv(src.getBurnConv());
            dst.setBurnDegree(src.getBurnDegree());
            dst.setBurnArea(src.getBurnArea());
            dst.setBurnAge(src.getBurnAge());
            dst.setBurnHeatTimer(src.getBurnHeatTimer());
            dst.setBurnHealTimer(src.getBurnHealTimer());
            dst.setAmputated(src.isAmputated());
            if (src instanceof LimbDataImpl sImpl && dst instanceof LimbDataImpl dImpl) {
                dImpl.setTourniquetTimer(sImpl.getTourniquetTimer());
                dImpl.setTourniquetClampedBleed(sImpl.getTourniquetClampedBleed());
                dImpl.setNecrotic(sImpl.isNecrotic());
                dImpl.setArterialLigated(sImpl.isArterialLigated());
                dImpl.setCompartmentBlood(sImpl.getCompartmentBlood());
                dImpl.setCompartmentPressure(sImpl.getCompartmentPressure());
                dImpl.setCompartmentTamponadedBleed(sImpl.getCompartmentTamponadedBleed());
                dImpl.setCompartmentIschemiaSec(sImpl.getCompartmentIschemiaSec());
                dImpl.setCompartmentSyndrome(sImpl.isCompartmentSyndrome());
                dImpl.setOrthopedicFixed(sImpl.isOrthopedicFixed());
                dImpl.setChestBraced(sImpl.isChestBraced());
                dImpl.setDelayedHemothoraxStrain(sImpl.getDelayedHemothoraxStrain());
                dImpl.setEmbeddedBulletCount(sImpl.getEmbeddedBulletCount());
                dImpl.setPerforationPacked(sImpl.isPerforationPacked());
                dImpl.setFractureTimerAuthoritative(sImpl.getFractureTimer());
            }
        }
    }

    // ====== 序列化 ======
    @Override
    public synchronized CompoundTag serializeNBT(HolderLookup.Provider provider) {
        CompoundTag tag = new CompoundTag();
        tag.putInt("bloodVolume", bloodVolume);
        tag.putFloat("bloodLossAccumulator", bloodLossAccumulator);
        tag.putFloat("bloodRegenAccumulator", bloodRegenAccumulator);
        tag.putFloat("bloodOxygen", bloodOxygen);
        tag.putFloat("brainHealth", brainHealth);
        tag.putInt("brainHealthRegenTimer", brainHealthRegenTimer);
        tag.putFloat("consciousness", consciousness);
        tag.putInt("heartRate", heartRate);
        tag.putInt("respirationRate", respirationRate);
        tag.putBoolean("underwater", underwater);
        tag.putInt("underwaterTimer", underwaterTimer);
        tag.putBoolean("inVFib", inVFib);
        tag.putBoolean("cardiacArrest", cardiacArrest);
        tag.putInt("vfibTimer", vfibTimer);
        tag.putInt("bradyTimer", bradyTimer);
        tag.putInt("hypoxiaTimer", hypoxiaTimer);
        tag.putInt("painDecayTimer", painDecayTimer);
        tag.putFloat("exerciseIntensity", exerciseIntensity);
        tag.putFloat("exerciseContribution", exerciseContribution);
        tag.putInt("runningTimer", runningTimer);
        tag.putInt("attackTimer", attackTimer);
        tag.putInt("heartEffectTimer", heartEffectTimer);
        tag.putBoolean("heartEffectSevere", heartEffectSevere);
        tag.putBoolean("bradycardiaActive", bradycardiaActive);
        tag.putBoolean("bradycardiaSevere", bradycardiaSevere);
        tag.putFloat("opioidConcentration", opioidConcentration);
        tag.putInt("addictionLevel", addictionLevel);
        tag.putFloat("adrenalineLevel", adrenalineLevel);
        tag.putInt("adrenalineCooldownSec", adrenalineCooldownSec);
        tag.putInt("adrenalineCrashSec", adrenalineCrashSec);
        tag.putBoolean("adrenalineFromInjector", adrenalineFromInjector);
        tag.putInt("naloxoneEffectSec", naloxoneEffectSec);
        tag.putInt("nsaidOnsetTimer", nsaidOnsetTimer);
        tag.putInt("nsaidRampTimer", nsaidRampTimer);
        tag.putInt("nsaidActiveTimer", nsaidActiveTimer);
        tag.putInt("nsaidLimbReliefAccumSec", nsaidLimbReliefAccumSec);
        tag.putInt("nsaidLimbRelievedCount", nsaidLimbRelievedCount);
        tag.putInt("nsaidTargetLimbOrdinal", nsaidTargetLimbOrdinal);
        tag.putFloat("txaConcentration", txaConcentration);
        tag.putFloat("chestBloodAccumulation", chestBloodAccumulation);
        tag.putInt("hemothoraxLevel", hemothoraxLevel);
        tag.putInt("hemothoraxVomitTimer", hemothoraxVomitTimer);
        tag.putFloat("lungContusion", lungContusion);
        tag.putInt("fractureTraumaTimer", fractureTraumaTimer);
        tag.putInt("intracranialBleedRate", intracranialBleedRate);
        tag.putFloat("intracranialAccumulation", intracranialAccumulation);
        tag.putInt("intracranialLevel", intracranialLevel);
        tag.putInt("intracranialOnsetTimer", intracranialOnsetTimer);
        tag.putInt("systolicBP", systolicBP);
        tag.putInt("diastolicBP", diastolicBP);
        tag.putFloat("meanArterialPressure", meanArterialPressure);
        tag.putFloat("peripheralResistance", peripheralResistance);
        tag.putFloat("cardiacOutput", cardiacOutput);
        tag.putInt("sirsLevel", sirsLevel);
        tag.putInt("sirsProgressionTimer", sirsProgressionTimer);
        tag.putInt("sirsRecoveryTimer", sirsRecoveryTimer);
        tag.putBoolean("sirsActive", sirsActive);
        tag.putBoolean("inCriticalState", inCriticalState);
        tag.putInt("criticalTimer", criticalTimer);
        tag.putFloat("toxinValue", toxinValue);
        tag.putFloat("burnTBSA", burnTBSA);
        tag.putFloat("burnEdema", burnEdema);
        tag.putFloat("inhalationInjury", inhalationInjury);
        tag.putInt("brainDamageTriggerTimer", brainDamageTriggerTimer);
        tag.putInt("brainDamageTriggerCooldown", brainDamageTriggerCooldown);
        tag.putBoolean("forcedTrigger90", forcedTrigger90);
        tag.putBoolean("forcedTrigger60", forcedTrigger60);
        tag.putBoolean("forcedTrigger30", forcedTrigger30);
        for (Limb limb : Limb.values()) {
            LimbData ld = limbs.get(limb);
            CompoundTag limbTag = new CompoundTag();
            limbTag.putInt("bleeding", ld.getBleeding());
            limbTag.putInt("painLevel", ld.getPainLevel());
            limbTag.putBoolean("bandaged", ld.isBandaged());
            limbTag.putBoolean("tourniqueted", ld.isTourniqueted());
            limbTag.putInt("infection", ld.getInfection());
            limbTag.putInt("infectionAgeTimer", ld.getInfectionAgeTimer());
            limbTag.putBoolean("hasOpenWound", ld.hasOpenWound());
            limbTag.putInt("internalBleeding", ld.getInternalBleedingRate());
            limbTag.putBoolean("fracture", ld.hasFracture());
            limbTag.putInt("fractureTimer", ld.getFractureTimer());
            limbTag.putBoolean("openFracture", ld.isOpenFracture());
            limbTag.putBoolean("splint", ld.hasSplint());
            limbTag.putBoolean("dislocation", ld.hasDislocation());
            limbTag.putBoolean("perforation", ld.hasPerforation());
            limbTag.putInt("naturalClottingTimer", ld.getNaturalClottingTimer());
            limbTag.putInt("clottingStartRate", ld.getClottingStartRate());
            limbTag.putInt("internalHealingTimer", ld.getInternalHealingTimer());
            limbTag.putInt("disinfectantTimer", ld.getDisinfectantTimer());
            limbTag.putFloat("infectionAccumulator", ld.getInfectionAccumulator());
            limbTag.putFloat("burnLoad", ld.getBurnLoad());
            limbTag.putFloat("burnConv", ld.getBurnConv());
            limbTag.putInt("burnDegree", ld.getBurnDegree());
            limbTag.putFloat("burnArea", ld.getBurnArea());
            limbTag.putInt("burnAge", ld.getBurnAge());
            limbTag.putInt("burnHeatTimer", ld.getBurnHeatTimer());
            limbTag.putInt("burnHealTimer", ld.getBurnHealTimer());
            limbTag.putBoolean("amputated", ld.isAmputated());
            if (ld instanceof LimbDataImpl lImpl) {
                limbTag.putInt("tourniquetTimer", lImpl.getTourniquetTimer());
                limbTag.putInt("tourniquetClampedBleed", lImpl.getTourniquetClampedBleed());
                limbTag.putBoolean("necrotic", lImpl.isNecrotic());
                limbTag.putBoolean("arterialLigated", lImpl.isArterialLigated());
                limbTag.putFloat("compartmentBlood", lImpl.getCompartmentBlood());
                limbTag.putFloat("compartmentPressure", lImpl.getCompartmentPressure());
                limbTag.putInt("compartmentTamponadedBleed", lImpl.getCompartmentTamponadedBleed());
                limbTag.putInt("compartmentIschemiaSec", lImpl.getCompartmentIschemiaSec());
                limbTag.putBoolean("compartmentSyndrome", lImpl.isCompartmentSyndrome());
                limbTag.putBoolean("orthopedicFixed", lImpl.isOrthopedicFixed());
                limbTag.putBoolean("chestBraced", lImpl.isChestBraced());
                limbTag.putInt("delayedHemothoraxStrain", lImpl.getDelayedHemothoraxStrain());
                limbTag.putInt("embeddedBulletCount", lImpl.getEmbeddedBulletCount());
                limbTag.putBoolean("perforationPacked", lImpl.isPerforationPacked());
            }
            tag.put(limb.name(), limbTag);
        }
        return tag;
    }

    public CompoundTag serializeNBT() {
        return serializeNBT(null);
    }

    @Override
    public synchronized void deserializeNBT(HolderLookup.Provider provider, CompoundTag tag) {
        bloodVolume = tag.getInt("bloodVolume");
        bloodLossAccumulator = tag.contains("bloodLossAccumulator") ? tag.getFloat("bloodLossAccumulator") : 0.0f;
        bloodRegenAccumulator = tag.contains("bloodRegenAccumulator") ? tag.getFloat("bloodRegenAccumulator") : 0.0f;
        bloodOxygen = tag.contains("bloodOxygen", 5) ? tag.getFloat("bloodOxygen") : (float) tag.getInt("bloodOxygen");
        brainHealth = tag.contains("brainHealth", 5) ? tag.getFloat("brainHealth") : (float) tag.getInt("brainHealth");
        brainHealthRegenTimer = tag.getInt("brainHealthRegenTimer");
        consciousness = tag.contains("consciousness", 5) ? tag.getFloat("consciousness") : (float) tag.getInt("consciousness");
        heartRate = tag.getInt("heartRate");
        respirationRate = tag.getInt("respirationRate");
        underwater = tag.getBoolean("underwater");
        underwaterTimer = tag.contains("underwaterTimer") ? tag.getInt("underwaterTimer") : 0;
        inVFib = tag.getBoolean("inVFib");
        cardiacArrest = tag.getBoolean("cardiacArrest");
        vfibTimer = tag.getInt("vfibTimer");
        bradyTimer = tag.getInt("bradyTimer");
        hypoxiaTimer = tag.contains("hypoxiaTimer") ? tag.getInt("hypoxiaTimer") : 0;
        painDecayTimer = tag.contains("painDecayTimer") ? tag.getInt("painDecayTimer") : 0;
        exerciseIntensity = tag.contains("exerciseIntensity") ? tag.getFloat("exerciseIntensity") : 0.0f;
        exerciseContribution = tag.contains("exerciseContribution") ? tag.getFloat("exerciseContribution") : 0.0f;
        runningTimer = tag.contains("runningTimer") ? tag.getInt("runningTimer") : 0;
        attackTimer = tag.contains("attackTimer") ? tag.getInt("attackTimer") : 0;
        heartEffectTimer = tag.getInt("heartEffectTimer");
        heartEffectSevere = tag.getBoolean("heartEffectSevere");
        bradycardiaActive = tag.getBoolean("bradycardiaActive");
        bradycardiaSevere = tag.getBoolean("bradycardiaSevere");
        opioidConcentration = tag.contains("opioidConcentration", 5)
                ? tag.getFloat("opioidConcentration")
                : (tag.contains("opioidConcentration") ? (float) tag.getInt("opioidConcentration") : 0.0f);
        addictionLevel = tag.contains("addictionLevel") ? tag.getInt("addictionLevel") : 0;
        adrenalineLevel = tag.contains("adrenalineLevel") ? tag.getFloat("adrenalineLevel") : 0.0f;
        adrenalineCooldownSec = tag.contains("adrenalineCooldownSec") ? tag.getInt("adrenalineCooldownSec") : 0;
        adrenalineCrashSec = tag.contains("adrenalineCrashSec") ? tag.getInt("adrenalineCrashSec") : 0;
        adrenalineFromInjector = tag.contains("adrenalineFromInjector") && tag.getBoolean("adrenalineFromInjector");
        naloxoneEffectSec = tag.contains("naloxoneEffectSec") ? tag.getInt("naloxoneEffectSec") : 0;
        nsaidOnsetTimer = tag.contains("nsaidOnsetTimer") ? tag.getInt("nsaidOnsetTimer") : 0;
        nsaidRampTimer = tag.contains("nsaidRampTimer") ? tag.getInt("nsaidRampTimer") : 0;
        nsaidActiveTimer = tag.contains("nsaidActiveTimer") ? tag.getInt("nsaidActiveTimer") : 0;
        nsaidLimbReliefAccumSec = tag.contains("nsaidLimbReliefAccumSec") ? tag.getInt("nsaidLimbReliefAccumSec") : 0;
        nsaidLimbRelievedCount = tag.contains("nsaidLimbRelievedCount") ? tag.getInt("nsaidLimbRelievedCount") : 0;
        nsaidTargetLimbOrdinal = tag.contains("nsaidTargetLimbOrdinal") ? tag.getInt("nsaidTargetLimbOrdinal") : -1;
        txaConcentration = tag.contains("txaConcentration") ? tag.getFloat("txaConcentration") : 0.0f;
        inCriticalState = tag.getBoolean("inCriticalState");
        criticalTimer = tag.getInt("criticalTimer");
        chestBloodAccumulation = tag.getFloat("chestBloodAccumulation");
        hemothoraxLevel = tag.getInt("hemothoraxLevel");
        hemothoraxVomitTimer = tag.getInt("hemothoraxVomitTimer");
        lungContusion = tag.contains("lungContusion") ? tag.getFloat("lungContusion") : 0.0f;
        fractureTraumaTimer = tag.contains("fractureTraumaTimer") ? tag.getInt("fractureTraumaTimer") : 0;
        intracranialBleedRate = tag.getInt("intracranialBleedRate");
        intracranialAccumulation = tag.getFloat("intracranialAccumulation");
        intracranialLevel = tag.getInt("intracranialLevel");
        intracranialOnsetTimer = tag.getInt("intracranialOnsetTimer");
        systolicBP = tag.contains("systolicBP") ? tag.getInt("systolicBP") : 120;
        diastolicBP = tag.contains("diastolicBP") ? tag.getInt("diastolicBP") : 80;
        meanArterialPressure = tag.contains("meanArterialPressure") ? tag.getFloat("meanArterialPressure") : 93.0f;
        peripheralResistance = tag.contains("peripheralResistance") ? tag.getFloat("peripheralResistance") : 1.0f;
        cardiacOutput = tag.contains("cardiacOutput") ? tag.getFloat("cardiacOutput") : 5.25f;
        sirsLevel = tag.contains("sirsLevel") ? tag.getInt("sirsLevel") : 0;
        sirsProgressionTimer = tag.contains("sirsProgressionTimer") ? tag.getInt("sirsProgressionTimer") : 0;
        sirsRecoveryTimer = tag.contains("sirsRecoveryTimer") ? tag.getInt("sirsRecoveryTimer") : 0;
        sirsActive = tag.contains("sirsActive") ? tag.getBoolean("sirsActive") : false;
        toxinValue = tag.contains("toxinValue") ? tag.getFloat("toxinValue") : 0.0f;
        burnTBSA = tag.contains("burnTBSA") ? tag.getFloat("burnTBSA") : 0.0f;
        burnEdema = tag.contains("burnEdema") ? tag.getFloat("burnEdema") : 0.0f;
        inhalationInjury = tag.contains("inhalationInjury") ? tag.getFloat("inhalationInjury") : 0.0f;
        brainDamageTriggerTimer = tag.contains("brainDamageTriggerTimer") ? tag.getInt("brainDamageTriggerTimer") : 0;
        brainDamageTriggerCooldown = tag.contains("brainDamageTriggerCooldown") ? tag.getInt("brainDamageTriggerCooldown") : 0;
        forcedTrigger90 = tag.contains("forcedTrigger90") ? tag.getBoolean("forcedTrigger90") : false;
        forcedTrigger60 = tag.contains("forcedTrigger60") ? tag.getBoolean("forcedTrigger60") : false;
        forcedTrigger30 = tag.contains("forcedTrigger30") ? tag.getBoolean("forcedTrigger30") : false;
        for (Limb limb : Limb.values()) {
            CompoundTag limbTag = tag.getCompound(limb.name());
            if (limbTag.isEmpty()) continue;
            LimbData ld = limbs.get(limb);
            ld.setBleeding(limbTag.getInt("bleeding"));
            ld.setPainLevel(limbTag.getInt("painLevel"));
            ld.setBandaged(limbTag.getBoolean("bandaged"));
            ld.setTourniqueted(limbTag.getBoolean("tourniqueted"));
            ld.setInfection(limbTag.getInt("infection"));
            ld.setInfectionAgeTimer(limbTag.contains("infectionAgeTimer") ? limbTag.getInt("infectionAgeTimer") : 0);
            ld.setOpenWound(limbTag.contains("hasOpenWound") ? limbTag.getBoolean("hasOpenWound") : false);
            ld.setInternalBleedingRate(limbTag.getInt("internalBleeding"));
            ld.setFracture(limbTag.getBoolean("fracture"));
            int loadedFracTimer = limbTag.contains("fractureTimer") ? limbTag.getInt("fractureTimer") : 0;
            if (ld instanceof LimbDataImpl ldAuth) {
                ldAuth.setFractureTimerAuthoritative(loadedFracTimer);
            } else {
                ld.setFractureTimer(loadedFracTimer);
            }
            ld.setOpenFracture(limbTag.contains("openFracture") ? limbTag.getBoolean("openFracture") : false);
            ld.setSplint(limbTag.contains("splint") ? limbTag.getBoolean("splint") : false);
            ld.setDislocation(limbTag.getBoolean("dislocation"));
            ld.setPerforation(limbTag.contains("perforation") ? limbTag.getBoolean("perforation") : false);
            ld.setNaturalClottingTimer(limbTag.getInt("naturalClottingTimer"));
            ld.setClottingStartRate(limbTag.getInt("clottingStartRate"));
            ld.setInternalHealingTimer(limbTag.getInt("internalHealingTimer"));
            ld.setDisinfectantTimer(limbTag.contains("disinfectantTimer") ? limbTag.getInt("disinfectantTimer") : 0);
            ld.setInfectionAccumulator(limbTag.contains("infectionAccumulator") ? limbTag.getFloat("infectionAccumulator") : 0.0f);
            ld.setBurnLoad(limbTag.contains("burnLoad") ? limbTag.getFloat("burnLoad") : 0.0f);
            ld.setBurnConv(limbTag.contains("burnConv") ? limbTag.getFloat("burnConv") : 0.0f);
            ld.setBurnDegree(limbTag.contains("burnDegree") ? limbTag.getInt("burnDegree") : 0);
            float loadedBurnArea = limbTag.contains("burnArea") ? limbTag.getFloat("burnArea") : 0.0f;
            if (loadedBurnArea > 1.0f) {
                loadedBurnArea = loadedBurnArea / 100.0f;
            }
            ld.setBurnArea(loadedBurnArea);
            ld.setBurnAge(limbTag.contains("burnAge") ? limbTag.getInt("burnAge") : 0);
            ld.setBurnHeatTimer(limbTag.contains("burnHeatTimer") ? limbTag.getInt("burnHeatTimer") : 0);
            ld.setBurnHealTimer(limbTag.contains("burnHealTimer") ? limbTag.getInt("burnHealTimer") : 0);
            ld.setAmputated(limbTag.contains("amputated") ? limbTag.getBoolean("amputated") : false);
            if (ld instanceof LimbDataImpl lImpl) {
                lImpl.setTourniquetTimer(limbTag.contains("tourniquetTimer") ? limbTag.getInt("tourniquetTimer") : 0);
                lImpl.setTourniquetClampedBleed(limbTag.contains("tourniquetClampedBleed") ? limbTag.getInt("tourniquetClampedBleed") : 0);
                lImpl.setNecrotic(limbTag.contains("necrotic") && limbTag.getBoolean("necrotic"));
                lImpl.setArterialLigated(limbTag.contains("arterialLigated") && limbTag.getBoolean("arterialLigated"));
                lImpl.setCompartmentBlood(limbTag.contains("compartmentBlood") ? limbTag.getFloat("compartmentBlood") : 0.0f);
                lImpl.setCompartmentPressure(limbTag.contains("compartmentPressure") ? limbTag.getFloat("compartmentPressure") : 4.0f);
                lImpl.setCompartmentTamponadedBleed(limbTag.contains("compartmentTamponadedBleed") ? limbTag.getInt("compartmentTamponadedBleed") : 0);
                lImpl.setCompartmentIschemiaSec(limbTag.contains("compartmentIschemiaSec") ? limbTag.getInt("compartmentIschemiaSec") : 0);
                lImpl.setCompartmentSyndrome(limbTag.contains("compartmentSyndrome") && limbTag.getBoolean("compartmentSyndrome"));
                lImpl.setOrthopedicFixed(limbTag.contains("orthopedicFixed") && limbTag.getBoolean("orthopedicFixed"));
                lImpl.setChestBraced(limbTag.contains("chestBraced") && limbTag.getBoolean("chestBraced"));
                lImpl.setDelayedHemothoraxStrain(limbTag.contains("delayedHemothoraxStrain") ? limbTag.getInt("delayedHemothoraxStrain") : 0);
                lImpl.setEmbeddedBulletCount(limbTag.contains("embeddedBulletCount") ? limbTag.getInt("embeddedBulletCount") : 0);
                lImpl.setPerforationPacked(limbTag.contains("perforationPacked") && limbTag.getBoolean("perforationPacked"));
            }
        }
    }

    public void deserializeNBT(CompoundTag tag) {
        deserializeNBT(null, tag);
    }

    // ====== LimbDataImpl 内部类 ======
    public static class LimbDataImpl implements LimbData {
        private int bleeding = 0;
        private int painLevel = 0;
        private boolean bandaged = false;
        private boolean tourniqueted = false;
        private int infection = 0;
        private int infectionAgeTimer = 0;
        private boolean hasOpenWound = false;
        private int internalBleeding = 0;
        private boolean fracture = false;
        private int fractureTimer = 0;
        private boolean openFracture = false;
        private boolean splint = false;
        private boolean dislocation = false;
        private boolean perforation = false;
        private int naturalClottingTimer = 0;
        private int clottingStartRate = 0;
        private int internalHealingTimer = 0;
        private int disinfectantTimer = 0;
        private float infectionAccumulator = 0.0f;

        // ====== 断肢与止血带缺血坏死 ======
        private boolean amputated = false;
        private int tourniquetTimer = 0;
        private int tourniquetClampedBleed = 0;
        private boolean necrotic = false;
        private boolean arterialLigated = false;
        private float compartmentBlood = 0.0f;
        private float compartmentPressure = 4.0f;
        private int compartmentTamponadedBleed = 0;
        private int compartmentIschemiaSec = 0;
        private boolean compartmentSyndrome = false;
        private boolean orthopedicFixed = false;
        private boolean chestBraced = false;
        private int delayedHemothoraxStrain = 0;
        private int embeddedBulletCount = 0;
        private boolean perforationPacked = false;

        // ====== 烧伤 ======
        private float burnLoad = 0.0f; // 热力缓冲负荷（未定型）
        private float burnConv = 0.0f; // 已转正负荷（定型判定用）
        private int burnDegree = 0; // 0无 1=I度 2=浅II 3=深II 4=III度
        private float burnArea = 0.0f; // 该肢体烧伤面积占比 0-1
        private int burnAge = 0; // 伤龄（秒）
        private int burnHeatTimer = 0; // 热力期倒计时（可冷却冲洗）
        private int burnHealTimer = 0; // 愈合计时

        @Override public synchronized int getBleeding() { return bleeding; }
        @Override public synchronized void setBleeding(int value) { this.bleeding = Math.max(0, value); }

        @Override public synchronized int getPainLevel() { return painLevel; }
        @Override public synchronized void setPainLevel(int value) { this.painLevel = Math.max(0, Math.min(10, value)); }

        @Override public synchronized boolean isBandaged() { return bandaged; }
        @Override public synchronized void setBandaged(boolean bandaged) { this.bandaged = bandaged; }

        @Override public synchronized boolean isTourniqueted() { return tourniqueted; }
        @Override public synchronized void setTourniqueted(boolean tourniqueted) { this.tourniqueted = tourniqueted; }

        @Override public synchronized int getInfection() { return infection; }
        @Override public synchronized void setInfection(int value) { this.infection = Math.max(0, Math.min(100, value)); }

        @Override public synchronized int getInfectionAgeTimer() { return infectionAgeTimer; }
        @Override public synchronized void setInfectionAgeTimer(int timer) { this.infectionAgeTimer = Math.max(0, timer); }

        @Override public synchronized boolean hasOpenWound() { return hasOpenWound; }
        @Override public synchronized void setOpenWound(boolean open) { this.hasOpenWound = open; }

        @Override public synchronized int getInternalBleedingRate() { return internalBleeding; }
        @Override public synchronized void setInternalBleedingRate(int value) { this.internalBleeding = Math.max(0, value); }

        @Override public synchronized boolean hasFracture() { return fracture; }
        @Override public synchronized void setFracture(boolean fracture) {
            this.fracture = fracture;
            if (!fracture) {
                this.orthopedicFixed = false;
                this.chestBraced = false;
                this.delayedHemothoraxStrain = 0;
            }
        }

        @Override public synchronized int getFractureTimer() { return fractureTimer; }
        @Override public synchronized void setFractureTimer(int seconds) {
            int clamped = Math.max(0, seconds);
            // ★ 防止外部旧 Loop 模块在夹板/手术固定愈合倒计时推进中将 299 错误重置回 300 ★
            if (this.fracture && (this.splint || this.orthopedicFixed || this.chestBraced)
                    && this.fractureTimer > 0 && clamped >= this.fractureTimer) {
                return;
            }
            this.fractureTimer = clamped;
        }

        public synchronized void setFractureTimerAuthoritative(int seconds) {
            this.fractureTimer = Math.max(0, seconds);
        }

        @Override public synchronized boolean isOpenFracture() { return openFracture; }
        @Override public synchronized void setOpenFracture(boolean open) { this.openFracture = open; }

        @Override public synchronized boolean hasSplint() { return splint; }
        @Override public synchronized void setSplint(boolean splinted) { this.splint = splinted; }

        @Override public synchronized boolean hasDislocation() { return dislocation; }
        @Override public synchronized void setDislocation(boolean dislocation) { this.dislocation = dislocation; }

        @Override public synchronized boolean hasPerforation() { return perforation; }
        @Override public synchronized void setPerforation(boolean perforation) {
            this.perforation = perforation;
            if (!perforation) {
                this.perforationPacked = false;
            }
        }

        @Override public synchronized int getNaturalClottingTimer() { return naturalClottingTimer; }
        @Override public synchronized void setNaturalClottingTimer(int seconds) { this.naturalClottingTimer = Math.max(0, seconds); }

        @Override public synchronized int getClottingStartRate() { return clottingStartRate; }
        @Override public synchronized void setClottingStartRate(int mLPerMin) { this.clottingStartRate = Math.max(0, mLPerMin); }

        @Override public synchronized int getInternalHealingTimer() { return internalHealingTimer; }
        @Override public synchronized void setInternalHealingTimer(int seconds) { this.internalHealingTimer = Math.max(0, seconds); }

        @Override public synchronized int getDisinfectantTimer() { return disinfectantTimer; }
        @Override public synchronized void setDisinfectantTimer(int seconds) {
            this.disinfectantTimer = Math.max(0, seconds);
        }
        @Override public synchronized float getInfectionAccumulator() { return infectionAccumulator; }
        @Override public synchronized void setInfectionAccumulator(float value) {
            this.infectionAccumulator = Math.max(0.0f, value);
        }

        @Override public synchronized boolean isAmputated() { return amputated; }
        @Override public synchronized void setAmputated(boolean amputated) {
            this.amputated = amputated;
            if (amputated) {
                this.embeddedBulletCount = 0;
                this.perforationPacked = false;
            }
        }

        public synchronized int getTourniquetTimer() { return tourniquetTimer; }
        public synchronized void setTourniquetTimer(int seconds) { this.tourniquetTimer = Math.max(0, seconds); }

        public synchronized int getTourniquetClampedBleed() { return tourniquetClampedBleed; }
        public synchronized void setTourniquetClampedBleed(int bleed) { this.tourniquetClampedBleed = Math.max(0, bleed); }

        public synchronized boolean isNecrotic() { return necrotic; }
        public synchronized void setNecrotic(boolean necrotic) { this.necrotic = necrotic; }

        public synchronized boolean isArterialLigated() { return arterialLigated; }
        public synchronized void setArterialLigated(boolean ligated) { this.arterialLigated = ligated; }

        public synchronized float getCompartmentBlood() { return compartmentBlood; }
        public synchronized void setCompartmentBlood(float ml) { this.compartmentBlood = Math.max(0.0f, ml); }

        public synchronized float getCompartmentPressure() { return compartmentPressure; }
        public synchronized void setCompartmentPressure(float mmHg) { this.compartmentPressure = Math.max(0.0f, mmHg); }

        public synchronized int getCompartmentTamponadedBleed() { return compartmentTamponadedBleed; }
        public synchronized void setCompartmentTamponadedBleed(int rate) { this.compartmentTamponadedBleed = Math.max(0, rate); }

        public synchronized int getCompartmentIschemiaSec() { return compartmentIschemiaSec; }
        public synchronized void setCompartmentIschemiaSec(int sec) { this.compartmentIschemiaSec = Math.max(0, sec); }

        public synchronized boolean isCompartmentSyndrome() { return compartmentSyndrome; }
        public synchronized void setCompartmentSyndrome(boolean cs) { this.compartmentSyndrome = cs; }

        public synchronized boolean isOrthopedicFixed() { return orthopedicFixed; }
        public synchronized void setOrthopedicFixed(boolean fixed) { this.orthopedicFixed = fixed; }

        public synchronized boolean isChestBraced() { return chestBraced; }
        public synchronized void setChestBraced(boolean braced) { this.chestBraced = braced; }

        public synchronized int getDelayedHemothoraxStrain() { return delayedHemothoraxStrain; }
        public synchronized void setDelayedHemothoraxStrain(int strain) { this.delayedHemothoraxStrain = Math.max(0, strain); }

        public synchronized int getEmbeddedBulletCount() { return embeddedBulletCount; }
        public synchronized void setEmbeddedBulletCount(int count) { this.embeddedBulletCount = Math.max(0, Math.min(16, count)); }

        public synchronized boolean isPerforationPacked() { return perforationPacked; }
        public synchronized void setPerforationPacked(boolean packed) { this.perforationPacked = packed && this.perforation; }

        @Override public synchronized float getBurnLoad() { return burnLoad; }
        @Override public synchronized void setBurnLoad(float load) { this.burnLoad = Math.max(0.0f, load); }
        @Override public synchronized float getBurnConv() { return burnConv; }
        @Override public synchronized void setBurnConv(float conv) { this.burnConv = Math.max(0.0f, conv); }
        @Override public synchronized int getBurnDegree() { return burnDegree; }
        @Override public synchronized void setBurnDegree(int degree) { this.burnDegree = Math.max(0, Math.min(4, degree)); }
        @Override public synchronized float getBurnArea() { return burnArea; }
        @Override public synchronized void setBurnArea(float area) { this.burnArea = Math.max(0.0f, Math.min(1.0f, area)); }
        @Override public synchronized int getBurnAge() { return burnAge; }
        @Override public synchronized void setBurnAge(int seconds) { this.burnAge = Math.max(0, seconds); }
        @Override public synchronized int getBurnHeatTimer() { return burnHeatTimer; }
        @Override public synchronized void setBurnHeatTimer(int seconds) { this.burnHeatTimer = Math.max(0, seconds); }
        @Override public synchronized int getBurnHealTimer() { return burnHealTimer; }
        @Override public synchronized void setBurnHealTimer(int seconds) { this.burnHealTimer = Math.max(0, seconds); }
        @Override public synchronized boolean hasBurn() { return burnDegree > 0 || burnLoad > 0.0f || burnConv > 0.0f; }

        @Override
        public synchronized int getColor() {
            if (this.necrotic) return 0xFF4A148C;
            int bleeding = this.bleeding;
            int internalBleed = this.internalBleeding;
            int pain = this.painLevel;
            if (bleeding == 0 && internalBleed == 0 && pain == 0) return 0xFF1B5E20;
            if (pain >= 7 || bleeding > 500 || internalBleed > 300) return 0xFFB71C1C;
            if (pain >= 4 || bleeding > 200 || internalBleed > 100) return 0xFFE65100;
            return 0xFFF57F17;
        }
    }
}